
g++ -I /usr/local/include/opencv4/ -I/usr/include/python3.8 -L/usr/local/lib -o selva test.cpp -lopencv_core -lopencv_highgui -lopencv_imgcodecs -lopencv_imgproc -lopencv_videoio 


