/*
 * test.cpp
 *
 *  Created on: 11-Aug-2022
 *      Author: selva
 */
#include <stdio.h>
// #include "Cameopen.h"
#include "Cameopen.cpp"
#include <iostream>
#include "opencv2/opencv.hpp"

using namespace std;

 //int argc, char** argv
int main(int argc, char *argv[]){
    char** fac;
    char** param;
    int ret;
    
    // if ( argc != 2 ) {
    // printf("no args\n");
    // return -1;
    // }
    
    // fac=argv;
    std::cout << "The arg count......:.........." << argv[0] << std::endl;
    std::cout << "THe arg 1 .......:.........." << argv[1] << std::endl;
    std::cout << "THe arg 2 .......:.........." << argv[2] << std::endl;
    ret=Cameopen(argv[1], argv[2]);
    std::cout << "From main........:.........." << ret << std::endl;
    //std::cout << "From main........:.........." << ret << std::endl;
    // cout<<"The result is"<<" "<<;
}
